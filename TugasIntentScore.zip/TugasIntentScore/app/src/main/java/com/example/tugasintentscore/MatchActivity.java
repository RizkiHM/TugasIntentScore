package com.example.tugasintentscore;

import android.app.Activity;

public class MatchActivity extends Activity {
}
